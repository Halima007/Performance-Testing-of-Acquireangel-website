/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 6;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 93.75, "KoPercent": 6.25};
    var dataset = [
        {
            "label" : "KO",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "OK",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.4921875, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.425, 500, 1500, "Home Page-1"], "isController": false}, {"data": [0.925, 500, 1500, "Sign In-0"], "isController": false}, {"data": [0.925, 500, 1500, "Sign In-1"], "isController": false}, {"data": [0.075, 500, 1500, "For Seller"], "isController": false}, {"data": [0.475, 500, 1500, "Home Page-0"], "isController": false}, {"data": [0.575, 500, 1500, "Join Now-0"], "isController": false}, {"data": [0.575, 500, 1500, "Join Now-1"], "isController": false}, {"data": [0.425, 500, 1500, "About"], "isController": false}, {"data": [0.0, 500, 1500, "For Buyer"], "isController": false}, {"data": [0.925, 500, 1500, "About-1"], "isController": false}, {"data": [0.925, 500, 1500, "About-0"], "isController": false}, {"data": [0.075, 500, 1500, "Join Now"], "isController": false}, {"data": [0.425, 500, 1500, "Sign In"], "isController": false}, {"data": [0.55, 500, 1500, "For Seller-1"], "isController": false}, {"data": [0.0, 500, 1500, "Home Page"], "isController": false}, {"data": [0.575, 500, 1500, "For Seller-0"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 320, 20, 6.25, 865.6843749999997, 0, 6657, 1875.8000000000002, 1924.9, 3838.310000000012, 7.288961778506674, 95.54519156302673, 1.0819552639970844], "isController": false}, "titles": ["Label", "#Samples", "KO", "Error %", "Average", "Min", "Max", "90th pct", "95th pct", "99th pct", "Transactions\/s", "Received", "Sent"], "items": [{"data": ["Home Page-1", 20, 0, 0.0, 1686.0, 1314, 4745, 3282.200000000002, 4676.399999999999, 4745.0, 0.536135535063264, 14.443826399313746, 0.06178124329830581], "isController": false}, {"data": ["Sign In-0", 20, 0, 0.0, 308.30000000000007, 257, 551, 520.1, 549.5, 551.0, 0.584932147870847, 0.13309491255264388, 0.06740429047730463], "isController": false}, {"data": ["Sign In-1", 20, 0, 0.0, 440.2, 261, 1445, 1403.2000000000003, 1443.4, 1445.0, 0.5848979353102883, 15.75900103088261, 0.0674003480142715], "isController": false}, {"data": ["For Seller", 20, 0, 0.0, 1710.55, 531, 2578, 1928.6, 2545.5499999999993, 2578.0, 0.5626828719333784, 12.141421547940581, 0.13737374803060995], "isController": false}, {"data": ["Home Page-0", 20, 0, 0.0, 606.9, 514, 1894, 569.7, 1827.799999999999, 1894.0, 0.5283736658564937, 0.1216704203212512, 0.060886809151431895], "isController": false}, {"data": ["Join Now-0", 20, 0, 0.0, 481.75000000000006, 257, 530, 528.6, 529.95, 530.0, 0.580905631880101, 0.13637667373435183, 0.07034404136048099], "isController": false}, {"data": ["Join Now-1", 20, 0, 0.0, 994.0, 263, 1443, 1147.2, 1428.2499999999998, 1443.0, 0.570645971239443, 7.619962711852317, 0.0691016605797763], "isController": false}, {"data": ["About", 20, 0, 0.0, 695.7000000000002, 521, 1650, 1617.9, 1648.4, 1650.0, 0.5855829478245593, 8.65215961161211, 0.14067715348129062], "isController": false}, {"data": ["For Buyer", 20, 20, 100.0, 0.0, 0, 0, 0.0, 0.0, 0.0, 0.5908070424199456, 0.6888902428216945, 0.0], "isController": false}, {"data": ["About-1", 20, 0, 0.0, 393.8, 261, 1128, 1089.0, 1126.05, 1128.0, 0.5900575306092345, 8.58032388626641, 0.07087605103997639], "isController": false}, {"data": ["About-0", 20, 0, 0.0, 301.09999999999997, 257, 527, 526.5, 527.0, 527.0, 0.5904059040590406, 0.13803044280442806, 0.0709178966789668], "isController": false}, {"data": ["Join Now", 20, 0, 0.0, 1476.3000000000002, 521, 1964, 1670.8, 1949.35, 1964.0, 0.5622873850825156, 7.640354399195928, 0.13617897607467175], "isController": false}, {"data": ["Sign In", 20, 0, 0.0, 749.2, 528, 1997, 1924.2000000000003, 1993.8999999999999, 1997.0, 0.5802820170602914, 15.766670414321359, 0.133736871119364], "isController": false}, {"data": ["For Seller-1", 20, 0, 0.0, 1221.3999999999999, 267, 2061, 1391.4, 2027.5499999999995, 2061.0, 0.5711674663011195, 12.189070710532329, 0.06972259110121087], "isController": false}, {"data": ["Home Page", 20, 0, 0.0, 2297.250000000001, 1840, 6657, 3866.900000000002, 6522.249999999998, 6657.0, 0.5099959200326397, 13.857047346746226, 0.11753812219502244], "isController": false}, {"data": ["For Seller-0", 20, 0, 0.0, 488.5, 259, 556, 544.9, 555.45, 556.0, 0.5855315162338612, 0.13883501185701322, 0.07147601516526628], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Percentile 1
            case 8:
            // Percentile 2
            case 9:
            // Percentile 3
            case 10:
            // Throughput
            case 11:
            // Kbytes/s
            case 12:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in authority at index 7: http:\\\/\\\/www.acquireangel.com \\\/buyers", 20, 100.0, 6.25], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 320, 20, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in authority at index 7: http:\\\/\\\/www.acquireangel.com \\\/buyers", 20, null, null, null, null, null, null, null, null], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["For Buyer", 20, 20, "Non HTTP response code: java.net.URISyntaxException\/Non HTTP response message: Illegal character in authority at index 7: http:\\\/\\\/www.acquireangel.com \\\/buyers", 20, null, null, null, null, null, null, null, null], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
